const express = require("express");
const path = require("path");
const app = express();
const port = 3000;
const base = path.join(__dirname, "..", "sdks");
const map = new Map([
  ["/<version>", path.join(base, "<downloaded-sdk-folder>")],
]);

for (const [key, value] of map) {
  app.use(key, express.static(value));
}

const content = JSON.stringify(Array.from(map.keys()));
const data = `Following UI5 versions are hosted: ${content}`;
app.get("/", (req, res) => {
  res.send(data);
});
app.get("/versions", (req, res) => {
  res.send(data);
});

app.listen(port, () => {
  console.log(`Web server is listening on port ${port}`);
});
